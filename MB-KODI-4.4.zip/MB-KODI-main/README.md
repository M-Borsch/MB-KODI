# MB-KODI
This Kodi Program Repository provides Kodi Addons that are supported by MB-KODI

![icon](MB-KODI-icon.png) 

This MB-KODI repository (https://m-borsch.github.io/MB-KODI or the mirror at http://borsch.myqnapcloud.com:8089/MB-KODI) is published as a Kodi repo that you directly install into Kodi. It serves up publicly available Kodi Addons supported by MB-KODI.

  <p>Supported by MB-KODI ✔️</p>

## Installation Instructions

>  1 - In Kodi use the "File Manager" to add a new 'source' pointing to either of these sources:
> 
>    http://borsch.myqnapcloud.com:8089/MB-KODI
> 
>    https://m-borsch.github.io/MB-KODI
> 
>  2 - In Kodi use the "Addons" - "Install from zip" option to install the MB-KODI repository utilizing the 'source' that you added in the previous step
> 
>  3 - In Kodi use the "Addons" - "Install from repo" option to install the associated 'Addon' from the MB-KODI repository that you added in the previous step
> 

# Repository of MB-KODI Addons

> [!NOTE]
> (Latest) - This is the latest version of the MB-KODI Repository

Version 4.4 of the MB-KODI Repo :sunglasses:
- This version includes the new version of "Insert/Swap Kodi Favourites" Program Addon called "Manage Kodi Favourites"
- Use the "Manage Kodi Favourites" Program Addon to associated sort (i.e. alphabetize), insert/swap, add a prefix or suffix and and color to item in your Kodi Favourites list.

<a href="MB-KODI-4.4.zip">MB-KODI-4.4.zip</a> (Latest)

<p>Supported by MB-KODI ✔️</p>

### Reference Articles available at: <a href="http://borsch.ca">borsch.ca</a>

- <a href="http://borsch.myqnapcloud.com:8083/index.php/articles-by-group/how-to/howto-create-a-github-kodi-addon?highlight=WyJrb2RpIl0="><b><i></i></b><i>Article on how to build a Kodi Repository and an Addon on borsch.ca</i></a>

Questions/Comments/thanks - <a href="mailto:kodi@borsch.ca">Send an email to MB-KODI</a><br />

<hr>

<p><img class="an1" draggable="false" src="https://fonts.gstatic.com/s/e/notoemoji/15.1/26a0_fe0f/72.png" alt="âš ï¸" width="20" loading="lazy" data-emoji="âš ï¸" aria-label="âš ï¸"> No Copyright infringement intended <img class="an1" draggable="false" src="https://fonts.gstatic.com/s/e/notoemoji/15.1/274c/72.png" alt="âŒ" width="20" loading="lazy" data-emoji="âŒ" aria-label="âŒ"> <a href="mailto:kodi@borsch.ca">Send an email to MB-KODI</a> to fix / Remove. (<span style="font-size: 8px;"><em>NAS</em></span>)</p>
<hr>

> [!IMPORTANT]
> MB-KODI Terms and Conditions / Disclaimer

Information published on or related to MB-KODI® repository is accurate and correct to our knowledge, however, there may be omissions, errors, or mistakes. Content published on or related to MB-KODI is for informational purposes only. By continuing to use these services, you agree to the following Terms and Conditions. 

Terms and Conditions / Disclaimer

This disclaimer ("Disclaimer") is a legally binding agreement between you ("user," "visitor," "you" or "your") and this repository ("MB-KODI", "we," "our," or "us"). It sets forth the general guidelines, disclosures, and terms of your use of this repository ("repository", "addons", "plugins", "services," "products," "information," or "content") operated and/or offered by MB-KODI.

Please read this disclaimer carefully before continuing to use this repository. Do not access and use the repository if you do not agree to the terms of this disclaimer. By using this repository or its services, you acknowledge that you have thoroughly read and also understand the terms of this disclaimer and hereby agree to be bound thereof.

General Disclaimer

The information or content displayed on this website/repository/addon is the intellectual property of the owner of MB-KODI. You may not reuse, republish, or reprint such information or content without our consent.

All the information or content related to MB-KODI is published in good faith and solely for general information and educational purposes. They are not in any way intended to serve as a substitute for professional advice. Our website/repository/addon is provided on an "as is" basis, and the author makes no representations or warranties of any kind or in any form, whether express or implied, about the completeness, timeliness, reliability, availability, validity, suitability, and accuracy, or guarantee that there will be no losses, errors, and omissions with respect to the information, or content contained on this website/repository/addon. Any action taken in reliance on any such information or content provided is strictly at your own risk.

As a result, the owner, its partners, employees, or agents will not be held liable for any accruing loss or damage as a result of the use of, reliance on, and reference to our repository, including without limitation, any special or incidental, direct or indirect, and punitive, or consequential loss or damage whatsoever.

We make every effort to keep the repository running smoothly. However, we take no legal responsibility and will not be liable if the website, repository or any addons are unavailable or inaccessible due to technical malfunctions beyond our control.

External Links Disclaimer

Through our repository, you can follow links to visit external websites, repositories, addons or content originating from third-parties that are not in any way affiliated with MB-KODI. While we try to provide only quality links to relevant and ethical websites, we have no control over the nature, content, accuracy, adequacy, reliability, validity, and availability of these sites. Accordingly, the inclusion of such links to other websites, repositories, addons does not in any way imply a recommendation or endorsement for the services or products contained on those sites. Also, owners and content may change without notice and may occur before we have the opportunity to remove broken or harmful links.

Professional Disclaimer

MB-Kodi does not contain professional advice. This site's information and content are provided for general information and educational purposes only and are not substitutes for professional advice.

We recommend that you also consult with the appropriate professionals before taking any actions based on such information, as the use or reliance of any such information contained on this site is solely at your own risk.

Affiliates Disclaimer

MB-KODI may contain links to affiliate sites, and we may receive an affiliate commission for any purchases made by you on those sites using such affiliate links.

Please know that other sites may have different privacy policies and terms beyond our control when you leave our website/repository/addon. MB-KODI does not monitor or investigate any transaction between you and any such third-party. We recommend checking the Privacy Policies of these sites and their Terms and Conditions before uploading any content or engaging in any business or transaction.

Testimonial Disclaimer

MB-KODI may contain testimonials by users of services or products that reflect such users' experiences and opinions. However, such experiences, opinions, and thoughts are personal to such users and do not necessarily represent all other users of our services or products. Testimonials are displayed verbatim except in grammatical and typing errors and long and extraneous information. Please be aware that the views or opinions in such testimonials belong to the user and do not represent the views of MB-KODI. As a result, the testimonials should not be construed as representing the adequacy, reliability, validity, and availability of such services or products.

Changes and Amendments

We reserve the exclusive right to change or modify this policy and its terms at any given time by posting the updated version here. Notification of those changes will be promptly posted on this site should we update, amend, or modify this document. The continued use of this website and its services after any such changes shall be construed to be consent to such changes. However, we advise you to frequently visit this disclaimer to ensure that you are up-to-date with the latest changes.

Consent

By proceeding to use MB-KODI, you hereby acknowledge that you have read this disclaimer in its entirety and hereby consent to this disclaimer and agree to all of its terms. If you do not agree to be bound by the terms of this disclaimer, you are not permitted to continue to use or access MB-KODI and its services.
