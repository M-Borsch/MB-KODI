# Manage Kodi Favourites Program Addon - To Do
![icon](https://github.com/M-Borsch/Manage-Kodi-Favourites/blob/main/Manage-Kodi-Fav-icon.png)  

### This is a simple & lightweight program add-on that lets you quickly manage your Kodi favourites by adding Prefixes, Suffixes and use Colors to better organize your Favourites list by insert/swapping entries and adding a Prefix/Suffix and Colors that works on multiple Kodi skins.
> [!NOTE]
> - [x] - (WYSIWYG Dialog) - Add ability to display a Thumbnail based version of your Favourites to edit
>
> - [x] - (WYSIWYG Dialog) - Add ability to call up Configuration Panel from menuu and dialog
> 
> - [x] - (Configuration Dialog) - Add ability to edit thumbnail sixe, label font size, insert/swap from picklist
> 
> - [x] - (Configuration Dialog) - Add ability to edit Prefix / Suffix labels from picklist
>
> - [x] -  (Configuration Dialog) - Add ability to add a Custom Prefix, Suffix and Color
>
> - [x] - (WYSIWYG Dialog) - Add ability to callup Configuration panel to change options
>
> - [x] - (WYSIWYG Dialog) - Add ability to modify the list with Insert/Swap, Prefix, Suffix and Colors
>
> - [x]  - (Write Out New file) - Add ability to save the change in order of the Favourites list
>
> - [x] - (Write Out New file) - Add ability to save the change in Prefix/Suffix and Colors in the Favourites list
>
> - [x] - (Sort and Filter) - Add ability to sort the Favourites list
>
> - [x] - (Save) - Add ability to Save Only the Favourites list
> 
> - [x] - (Reload) - Add ability to Reload User Kodi Profile
> 
> - [x] - (Overwrite Favourites) - Add ability to Overwrite the Favourites file (favourites.xml)
> 
> - [x] - (Filter) - Add Filter Suffix to allow for categories to filter - personal groups
> 



